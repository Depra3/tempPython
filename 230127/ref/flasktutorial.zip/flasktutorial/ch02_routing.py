from flask import Flask

app = Flask(__name__)
@app.route('/')
def main():
    return "첫번째 페이지"

@app.route('/greet')
def greeting():
    return 'Hello World!!'

@app.route('/greet1')
def greeting2():
    return '안녕'

@app.route('/greet2')
def greeting3():
    return '하하하하'

if __name__ == "__main__":
    app.run(debug=True)